package manish.com;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Qustion {
	@Id
	private int qustionId;
	private String qustion;
	@OneToMany(mappedBy = "qus")
	private List<Answer>ans;

	public int getQustionId() {
		return qustionId;
	}

	public void setQustionId(int qustionId) {
		this.qustionId = qustionId;
	}

	public String getQustion() {
		return qustion;
	}

	public void setQustion(String qustion) {
		this.qustion = qustion;
	}

	public List<Answer> getAns() {
		return ans;
	}

	public void setAns(List<Answer> ans) {
		this.ans = ans;
	}

	public Qustion() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	

}
