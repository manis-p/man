package manish.com;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Answer {
	@Id
	private int answerId;
	private String answer;
	@ManyToOne
	private Qustion qus;
	public int getAnswerId() {
		return answerId;
	}
	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Answer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Qustion getQus() {
		return qus;
	}
	public void setQus(Qustion qus) {
		this.qus = qus;
	}
	
	
	
	
	

}
